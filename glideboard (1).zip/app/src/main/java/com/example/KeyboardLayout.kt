package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class KeyboardPage {
    LETTERS,
    NUMBERS,
    SYMBOLS
}

@Composable
fun KeyboardLayout(
    theme: KeyboardTheme,
    emojiPrefs: EmojiSharedPreferences,
    modifier: Modifier = Modifier,
    onText: (String) -> Unit = {},
    onBackspace: () -> Unit = {},
    onSpace: () -> Unit = {},
    onEnter: () -> Unit = {},
    onThemeCycle: () -> Unit = {},
    onSettingsClick: () -> Unit = {},
    onHideKeyboard: () -> Unit = {}
) {
    val haptic = LocalHapticFeedback.current
    var currentPage by remember { mutableStateOf(KeyboardPage.LETTERS) }
    var isShifted by remember { mutableStateOf(false) }
    
    // Gesture engine state
    var isGestureWheelActive by remember { mutableStateOf(false) }
    var dragStartOffset by remember { mutableStateOf(Offset.Zero) }
    var currentDragOffset by remember { mutableStateOf(Offset.Zero) }
    var activeDirection by remember { mutableStateOf<String?>(null) }

    val emojis = remember(emojiPrefs) { emojiPrefs.getAllEmojis() }

    // Helper tap event with haptics
    val playTap: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(theme.getComposeBackground())
            .padding(vertical = 4.dp)
    ) {
        Column {
            // Toolbar (Gboard visual layout style)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Help text indicator or title
                    Icon(
                        imageVector = Icons.Default.Gesture,
                        contentDescription = "Shortcuts Info",
                        tint = theme.getComposeKeyText().copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Hold & Glide Gesture Key",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = theme.getComposeKeyText().copy(alpha = 0.7f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Theme Quick Cycle Button
                    IconButton(
                        onClick = {
                            playTap()
                            onThemeCycle()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ColorLens,
                            contentDescription = "Theme Cycle",
                            tint = theme.getComposeKeyText()
                        )
                    }

                    // Settings Button
                    IconButton(
                        onClick = {
                            playTap()
                            onSettingsClick()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = theme.getComposeKeyText()
                        )
                    }

                    // Hide Keyboard Indicator
                    IconButton(
                        onClick = {
                            playTap()
                            onHideKeyboard()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Hide Keyboard",
                            tint = theme.getComposeKeyText()
                        )
                    }
                }
            }

            // Keyboard grid body
            when (currentPage) {
                KeyboardPage.LETTERS -> {
                    LettersKeyboard(
                        theme = theme,
                        isShifted = isShifted,
                        onShiftToggle = {
                            playTap()
                            isShifted = !isShifted
                        },
                        onKeyTap = { char ->
                            playTap()
                            onText(if (isShifted) char.uppercase() else char.lowercase())
                            // Standard soft-reset shift after a character if shifted
                            if (isShifted) {
                                isShifted = false
                            }
                        },
                        onBackspace = {
                            playTap()
                            onBackspace()
                        },
                        onSpace = {
                            playTap()
                            onSpace()
                        },
                        onEnter = {
                            playTap()
                            onEnter()
                        },
                        onPageToggle = {
                            playTap()
                            currentPage = KeyboardPage.NUMBERS
                        },
                        // Visual gesture activation key is on Row 4
                        emojiPrefs = emojiPrefs,
                        onGestureWheelState = { active, start, current, dir ->
                            if (active) {
                                if (!isGestureWheelActive) {
                                    playTap()
                                }
                                isGestureWheelActive = true
                                dragStartOffset = start
                                currentDragOffset = current
                                activeDirection = dir
                            } else {
                                if (isGestureWheelActive) {
                                    playTap()
                                    // Submit the selected emoji
                                    activeDirection?.let { d ->
                                        val emojiToType = emojiPrefs.getEmoji(d)
                                        onText(emojiToType)
                                    }
                                }
                                isGestureWheelActive = false
                                dragStartOffset = Offset.Zero
                                currentDragOffset = Offset.Zero
                                activeDirection = null
                            }
                        }
                    )
                }
                KeyboardPage.NUMBERS -> {
                    NumbersKeyboard(
                        theme = theme,
                        onKeyTap = { char ->
                            playTap()
                            onText(char)
                        },
                        onBackspace = {
                            playTap()
                            onBackspace()
                        },
                        onSpace = {
                            playTap()
                            onSpace()
                        },
                        onEnter = {
                            playTap()
                            onEnter()
                        },
                        onPageToggle = {
                            playTap()
                            currentPage = KeyboardPage.LETTERS
                        },
                        onSymbolToggle = {
                            playTap()
                            currentPage = KeyboardPage.SYMBOLS
                        }
                    )
                }
                KeyboardPage.SYMBOLS -> {
                    SymbolsKeyboard(
                        theme = theme,
                        onKeyTap = { char ->
                            playTap()
                            onText(char)
                        },
                        onBackspace = {
                            playTap()
                            onBackspace()
                        },
                        onSpace = {
                            playTap()
                            onSpace()
                        },
                        onEnter = {
                            playTap()
                            onEnter()
                        },
                        onPageToggle = {
                            playTap()
                            currentPage = KeyboardPage.LETTERS
                        },
                        onPageBack = {
                            playTap()
                            currentPage = KeyboardPage.NUMBERS
                        }
                    )
                }
            }
        }

        // FULL VISUAL GESTURE RADIAL WHEEL OVERLAY
        AnimatedVisibility(
            visible = isGestureWheelActive,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.matchParentSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(theme.getComposeBackground().copy(alpha = 0.95f))
                    .pointerInput(Unit) {},
                contentAlignment = Alignment.Center
            ) {
                // Radial graphic visual elements
                val radialCenter = Offset(0f, 0f)
                val baseRadius = 100.dp
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Emoji Glide Pad",
                        color = theme.getComposeAccent(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activeDirection?.let { "Slide to select: ${emojiPrefs.getEmoji(it)}" } ?: "Slide in any direction",
                        color = theme.getComposeKeyText().copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Representing the joystick visually
                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(CircleShape)
                            .background(theme.getComposeSpecialKeyBg().copy(alpha = 0.5f))
                            .border(1.5.dp, theme.getComposeKeyText().copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        // Background Grid indicators for all 8 paths
                        val directions = listOf(
                            "up" to Alignment.TopCenter,
                            "down" to Alignment.BottomCenter,
                            "left" to Alignment.CenterStart,
                            "right" to Alignment.CenterEnd,
                            "up_left" to Alignment.TopStart,
                            "up_right" to Alignment.TopEnd,
                            "down_left" to Alignment.BottomStart,
                            "down_right" to Alignment.BottomEnd
                        )

                        directions.forEach { (dir, alignment) ->
                            val isHighlighted = activeDirection == dir
                            val scale = if (isHighlighted) 1.4f else 1.0f
                            val emojiVal = emojiPrefs.getEmoji(dir)

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                contentAlignment = alignment
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isHighlighted) theme.getComposeAccent() else theme.getComposeKeyBg()
                                        )
                                        .border(
                                            width = if (isHighlighted) 2.dp else 1.dp,
                                            color = if (isHighlighted) Color.White else theme.getComposeKeyText().copy(alpha = 0.1f),
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = emojiVal,
                                        fontSize = if (isHighlighted) 24.sp else 18.sp,
                                        modifier = Modifier.padding(4.dp)
                                    )
                                }
                            }
                        }

                        // Center indicator / touch feedback joystick dot
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(theme.getComposeAccent().copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(theme.getComposeAccent())
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Release finger to type highlighted emoji",
                        color = theme.getComposeKeyText().copy(alpha = 0.5f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun LettersKeyboard(
    theme: KeyboardTheme,
    isShifted: Boolean,
    emojiPrefs: EmojiSharedPreferences,
    onShiftToggle: () -> Unit,
    onKeyTap: (String) -> Unit,
    onBackspace: () -> Unit,
    onSpace: () -> Unit,
    onEnter: () -> Unit,
    onPageToggle: () -> Unit,
    onGestureWheelState: (Boolean, Offset, Offset, String?) -> Unit
) {
    val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Row 1
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            row1.forEach { char ->
                val displayChar = if (isShifted) char.uppercase() else char.lowercase()
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(char) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = displayChar,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            row2.forEach { char ->
                val displayChar = if (isShifted) char.uppercase() else char.lowercase()
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(char) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = displayChar,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Row 3 (Shift, Z-M, Backspace)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Shift Key
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isShifted) theme.getComposeAccent() else theme.getComposeSpecialKeyBg())
                    .clickable { onShiftToggle() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowUpward,
                    contentDescription = "Shift",
                    tint = if (isShifted) Color.White else theme.getComposeKeyText()
                )
            }

            row3.forEach { char ->
                val displayChar = if (isShifted) char.uppercase() else char.lowercase()
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(char) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = displayChar,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Backspace Key
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = theme.getComposeKeyText()
                )
            }
        }

        // Row 4 (Toggle Page, Emoji/Gesture Key, Space, Period, Enter)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Page Toggler (?123)
            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onPageToggle() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "?123",
                    color = theme.getComposeKeyText(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Interactive Drag/Swipe Gesture Emoji Shortcut Key
            var dragStart by remember { mutableStateOf(Offset.Zero) }
            var currentDrag by remember { mutableStateOf(Offset.Zero) }

            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeAccent().copy(alpha = 0.2f))
                    .border(1.dp, theme.getComposeAccent().copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .pointerInput(emojiPrefs) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                dragStart = offset
                                currentDrag = offset
                                onGestureWheelState(true, dragStart, currentDrag, null)
                            },
                            onDragEnd = {
                                onGestureWheelState(false, Offset.Zero, Offset.Zero, null)
                            },
                            onDragCancel = {
                                onGestureWheelState(false, Offset.Zero, Offset.Zero, null)
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                currentDrag += dragAmount
                                val dx = currentDrag.x - dragStart.x
                                val dy = currentDrag.y - dragStart.y
                                val activeDir = calculate8WayDirection(dx, dy, pixelsThreshold = 50f)
                                onGestureWheelState(true, dragStart, currentDrag, activeDir)
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Glide 🚀",
                        color = theme.getComposeAccent(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Gestures",
                        color = theme.getComposeKeyText().copy(alpha = 0.7f),
                        fontSize = 8.sp
                    )
                }
            }

            // Spacebar Key
            Box(
                modifier = Modifier
                    .weight(3.8f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onSpace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Language",
                    tint = theme.getComposeKeyText().copy(alpha = 0.2f),
                    modifier = Modifier.padding(end = 6.dp)
                )
                Text(
                    text = "Space",
                    color = theme.getComposeKeyText().copy(alpha = 0.6f),
                    fontSize = 13.sp
                )
            }

            // Period (.) button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onKeyTap(".") },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = ".",
                    color = theme.getComposeKeyText(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Enter key
            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeAccent())
                    .clickable { onEnter() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Enter",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun NumbersKeyboard(
    theme: KeyboardTheme,
    onKeyTap: (String) -> Unit,
    onBackspace: () -> Unit,
    onSpace: () -> Unit,
    onEnter: () -> Unit,
    onPageToggle: () -> Unit,
    onSymbolToggle: () -> Unit
) {
    val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val row2 = listOf("@", "#", "$", "%", "&", "-", "_", "+", "(", ")")
    val row3 = listOf("*", "\"", "'", ":", ";", "!", "?")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Row 1
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            row1.forEach { num ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(num) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = num,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            row2.forEach { sym ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(sym) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sym,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Row 3
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Equal tag page switch key (=\<)
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onSymbolToggle() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "=\\<",
                    color = theme.getComposeKeyText(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            row3.forEach { sym ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(sym) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sym,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Backspace Key
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = theme.getComposeKeyText()
                )
            }
        }

        // Row 4
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Toggle Alphabet (ABC)
            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onPageToggle() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ABC",
                    color = theme.getComposeKeyText(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Quick comma (,) button
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onKeyTap(",") },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = ",",
                    color = theme.getComposeKeyText(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Spacebar Key
            Box(
                modifier = Modifier
                    .weight(3.8f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onSpace() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Space",
                    color = theme.getComposeKeyText().copy(alpha = 0.6f),
                    fontSize = 13.sp
                )
            }

            // Period (.) button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onKeyTap(".") },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = ".",
                    color = theme.getComposeKeyText(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Enter key
            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeAccent())
                    .clickable { onEnter() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Enter",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SymbolsKeyboard(
    theme: KeyboardTheme,
    onKeyTap: (String) -> Unit,
    onBackspace: () -> Unit,
    onSpace: () -> Unit,
    onEnter: () -> Unit,
    onPageToggle: () -> Unit,
    onPageBack: () -> Unit
) {
    val row1 = listOf("~", "`", "|", "•", "√", "π", "÷", "×", "{", "}")
    val row2 = listOf("£", "¢", "€", "¥", "^", "°", "=", "\\", "[", "]")
    val row3 = listOf("<", ">", "%", "©", "®", "™", "✓")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Row 1
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            row1.forEach { sym ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(sym) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sym,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            row2.forEach { sym ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(sym) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sym,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Row 3
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Special Toggle back (?123)
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onPageBack() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "?123",
                    color = theme.getComposeKeyText(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            row3.forEach { sym ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.getComposeKeyBg())
                        .clickable { onKeyTap(sym) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sym,
                        color = theme.getComposeKeyText(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Backspace Key
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = theme.getComposeKeyText()
                )
            }
        }

        // Row 4
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Toggle Alphabet (ABC)
            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeSpecialKeyBg())
                    .clickable { onPageToggle() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ABC",
                    color = theme.getComposeKeyText(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Quick comma (,) button
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onKeyTap(",") },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = ",",
                    color = theme.getComposeKeyText(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Spacebar Key
            Box(
                modifier = Modifier
                    .weight(3.8f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onSpace() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Space",
                    color = theme.getComposeKeyText().copy(alpha = 0.6f),
                    fontSize = 13.sp
                )
            }

            // Period (.) button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeKeyBg())
                    .clickable { onKeyTap(".") },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = ".",
                    color = theme.getComposeKeyText(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Enter key
            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.getComposeAccent())
                    .clickable { onEnter() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Enter",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Mathematical 8-way directional calculator based on delta-x / delta-y with deadzone threshold.
 */
fun calculate8WayDirection(dx: Float, dy: Float, pixelsThreshold: Float): String? {
    val distance = sqrt((dx * dx + dy * dy).toDouble())
    if (distance < pixelsThreshold) return null

    // Determine angle [-180, 180] from atan2
    var angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble()))
    if (angle < 0) {
        angle += 360.0
    }

    // 0 is Right, 90 is Down, 180 is Left, 270 is Up.
    return when {
        (angle >= 337.5 || angle < 22.5) -> "right"
        (angle >= 22.5 && angle < 67.5) -> "down_right"
        (angle >= 67.5 && angle < 112.5) -> "down"
        (angle >= 112.5 && angle < 157.5) -> "down_left"
        (angle >= 157.5 && angle < 202.5) -> "left"
        (angle >= 202.5 && angle < 247.5) -> "up_left"
        (angle >= 247.5 && angle < 292.5) -> "up"
        (angle >= 292.5 && angle < 337.5) -> "up_right"
        else -> null
    }
}
