package com.example

import android.content.Intent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import com.example.ui.theme.MyApplicationTheme

class IMEService : ComposeInputMethodService() {

    private lateinit var emojiPrefs: EmojiSharedPreferences
    private var currentThemeState by mutableStateOf(KeyboardTheme.GBOARD_DARK)

    override fun onCreate() {
        super.onCreate()
        emojiPrefs = EmojiSharedPreferences(this)
        loadSavedTheme()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Refresh preferences and theme every time keyboard opens
        loadSavedTheme()
    }

    private fun loadSavedTheme() {
        val themeId = emojiPrefs.themeId
        val customTheme = emojiPrefs.getCustomTheme()
        currentThemeState = KeyboardTheme.getById(themeId, customTheme)
    }

    override fun onCreateInputView(): View {
        return createComposeView {
            MyApplicationTheme {
                KeyboardLayout(
                    theme = currentThemeState,
                    emojiPrefs = emojiPrefs,
                    onText = { text ->
                        currentInputConnection?.commitText(text, 1)
                    },
                    onBackspace = {
                        val conn = currentInputConnection ?: return@KeyboardLayout
                        val selected = conn.getSelectedText(0)
                        if (selected.isNullOrEmpty()) {
                            conn.deleteSurroundingText(1, 0)
                        } else {
                            conn.commitText("", 1)
                        }
                    },
                    onSpace = {
                        currentInputConnection?.commitText(" ", 1)
                    },
                    onEnter = {
                        val conn = currentInputConnection ?: return@KeyboardLayout
                        val editorInfo = currentInputEditorInfo
                        if (editorInfo != null && editorInfo.actionId != 0) {
                            conn.performEditorAction(editorInfo.actionId)
                        } else {
                            conn.commitText("\n", 1)
                        }
                    },
                    onThemeCycle = {
                        cycleTheme()
                    },
                    onSettingsClick = {
                        val intent = Intent(this@IMEService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                    },
                    onHideKeyboard = {
                        requestHideSelf(0)
                    }
                )
            }
        }
    }

    private fun cycleTheme() {
        val themes = KeyboardTheme.ALL_THEMES + listOf(emojiPrefs.getCustomTheme())
        val currentIndex = themes.indexOfFirst { it.id == currentThemeState.id }
        val nextIndex = (currentIndex + 1) % themes.size
        val nextTheme = themes[nextIndex]

        emojiPrefs.themeId = nextTheme.id
        currentThemeState = nextTheme
    }
}
