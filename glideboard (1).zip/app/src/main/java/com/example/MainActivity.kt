package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var emojiPrefs: EmojiSharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        emojiPrefs = EmojiSharedPreferences(this)

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    GlideBoardHome(
                        emojiPrefs = emojiPrefs,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun GlideBoardHome(emojiPrefs: EmojiSharedPreferences, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) }
    
    // Status Trackers
    var isKeyboardEnabled by remember { mutableStateOf(false) }
    var isKeyboardActive by remember { mutableStateOf(false) }

    // Read states safely
    fun checkKeyboardStatus() {
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            if (imm != null) {
                val enabledList = imm.enabledInputMethodList
                isKeyboardEnabled = enabledList.any { it.packageName == context.packageName }
            } else {
                isKeyboardEnabled = false
            }

            val currentId = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.DEFAULT_INPUT_METHOD
            )
            isKeyboardActive = currentId != null && currentId.contains(context.packageName)
        } catch (e: Exception) {
            e.printStackTrace()
            isKeyboardEnabled = false
            isKeyboardActive = false
        }
    }

    // Check on startup & resume
    LaunchedEffect(Unit) {
        checkKeyboardStatus()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Header Graphic
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(vertical = 18.dp, horizontal = 20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Keyboard,
                        contentDescription = "Logo",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        text = "GlideBoard",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Google Keyboard replica + Swipe Gestures",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // Standard M3 navigation tabs
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0; checkKeyboardStatus() },
                text = { Text("Set Up & Test", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Keyboard, contentDescription = "Setup", modifier = Modifier.size(20.dp)) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1; checkKeyboardStatus() },
                text = { Text("Themes Studio", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.ColorLens, contentDescription = "Themes", modifier = Modifier.size(20.dp)) }
            )
            Tab(
                selected = activeTab == 2,
                onClick = { activeTab = 2; checkKeyboardStatus() },
                text = { Text("Emoji Gestures", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Gesture, contentDescription = "Gestures", modifier = Modifier.size(20.dp)) }
            )
        }

        // Tab Screens Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeTab) {
                0 -> SetupAndTestTab(
                    emojiPrefs = emojiPrefs,
                    isKeyboardEnabled = isKeyboardEnabled,
                    isKeyboardActive = isKeyboardActive,
                    onRefreshStatus = { checkKeyboardStatus() }
                )
                1 -> ThemesTab(emojiPrefs = emojiPrefs)
                2 -> GesturesTab(emojiPrefs = emojiPrefs)
            }
        }
    }
}

@Composable
fun SetupAndTestTab(
    emojiPrefs: EmojiSharedPreferences,
    isKeyboardEnabled: Boolean,
    isKeyboardActive: Boolean,
    onRefreshStatus: () -> Unit
) {
    val context = LocalContext.current
    var testInputText by remember { mutableStateOf("") }
    var activeThemeState by remember { mutableStateOf(KeyboardTheme.GBOARD_DARK) }

    LaunchedEffect(Unit) {
        val currentThemeId = emojiPrefs.themeId
        activeThemeState = KeyboardTheme.getById(currentThemeId, emojiPrefs.getCustomTheme())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Step 1: Enable Service
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isKeyboardEnabled) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "1. Enable GlideBoard Keyboard",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isKeyboardEnabled) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isKeyboardEnabled) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Enabled",
                            tint = Color(0xFF2E7D32)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Go to Android system settings, toggle the keyboard switch on for GlideBoard.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isKeyboardEnabled) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Open Keyboard Settings")
                }
            }
        }

        // Step 2: Choose GlideBoard
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isKeyboardActive) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "2. Active Switch Method",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isKeyboardActive) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isKeyboardActive) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Active",
                            tint = Color(0xFF2E7D32)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Trigger the switcher dialog to select GlideBoard as your primary active tool.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.showInputMethodPicker()
                    },
                    enabled = isKeyboardEnabled,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isKeyboardActive) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Switch Active Keyboard")
                }
            }
        }

        // Status Syncer Quick Refresh
        OutlinedButton(
            onClick = { onRefreshStatus() },
            modifier = Modifier.align(Alignment.End)
        ) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh Status", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Verify Status")
        }

        // Step 3: Playground Text Field
        Text(
            text = "Testing Playground & Interactive Preview",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        OutlinedTextField(
            value = testInputText,
            onValueChange = { testInputText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Try typing here!") },
            placeholder = { Text("Interact with the quick keyboard below...") },
            trailingIcon = {
                if (testInputText.isNotEmpty()) {
                    IconButton(onClick = { testInputText = "" }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            }
        )

        // Visual inline keyboard simulator helper so user can preview GlideBoard immediately in the browser!
        Card(
            title = "Visual Simulator Panel",
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.background(MaterialTheme.colorScheme.surface)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "📱 Click or slide below to test layout, colors & shortcuts!",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }

                KeyboardLayout(
                    theme = activeThemeState,
                    emojiPrefs = emojiPrefs,
                    onText = { text ->
                        testInputText += text
                    },
                    onBackspace = {
                        if (testInputText.isNotEmpty()) {
                            testInputText = testInputText.substring(0, testInputText.length - 1)
                        }
                    },
                    onSpace = {
                        testInputText += " "
                    },
                    onEnter = {
                        testInputText += "\n"
                    },
                    onThemeCycle = {
                        val themes = KeyboardTheme.ALL_THEMES + listOf(emojiPrefs.getCustomTheme())
                        val currentIndex = themes.indexOfFirst { it.id == activeThemeState.id }
                        val nextIndex = (currentIndex + 1) % themes.size
                        val nextTheme = themes[nextIndex]
                        emojiPrefs.themeId = nextTheme.id
                        activeThemeState = nextTheme
                    },
                    onSettingsClick = {
                        // Click setting is already on standard screen
                    },
                    onHideKeyboard = {}
                )
            }
        }
    }
}

@Composable
fun ThemesTab(emojiPrefs: EmojiSharedPreferences) {
    var selectedThemeId by remember { mutableStateOf("") }
    val customTheme by remember { mutableStateOf(emojiPrefs.getCustomTheme()) }
    
    // Custom Color Swatch Builder States
    var customBg by remember { mutableStateOf(customTheme.backgroundColor) }
    var customKey by remember { mutableStateOf(customTheme.keyColor) }
    var customText by remember { mutableStateOf(customTheme.keyTextColor) }
    var customSpKey by remember { mutableStateOf(customTheme.specialKeyColor) }
    var customAccent by remember { mutableStateOf(customTheme.accentColor) }

    LaunchedEffect(Unit) {
        selectedThemeId = emojiPrefs.themeId
    }

    val saveThemeChanges = {
        val nextCustom = KeyboardTheme(
            id = "custom",
            name = "My Custom Design",
            isDark = true,
            backgroundColor = customBg,
            keyColor = customKey,
            keyTextColor = customText,
            specialKeyColor = customSpKey,
            accentColor = customAccent
        )
        emojiPrefs.saveCustomTheme(nextCustom)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Select Keyboard Theme",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Predefined keyboard previews list
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(KeyboardTheme.ALL_THEMES) { theme ->
                val isActive = selectedThemeId == theme.id
                ThemeCard(
                    theme = theme,
                    isActive = isActive,
                    onClick = {
                        selectedThemeId = theme.id
                        emojiPrefs.themeId = theme.id
                    }
                )
            }

            // Custom designer item card
            val isCustomActive = selectedThemeId == "custom"
            item {
                ThemeCard(
                    theme = KeyboardTheme(
                        id = "custom",
                        name = "Custom Theme",
                        isDark = true,
                        backgroundColor = customBg,
                        keyColor = customKey,
                        keyTextColor = customText,
                        specialKeyColor = customSpKey,
                        accentColor = customAccent
                    ),
                    isActive = isCustomActive,
                    onClick = {
                        selectedThemeId = "custom"
                        emojiPrefs.themeId = "custom"
                    }
                )
            }
        }

        // Custom Theme Specifier Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Custom Theme Designer Studio",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Customize the colors below to draw your layout exactly the way you like.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )

                // Background swatches
                ColorSwatchRow("Background Color", currentVal = customBg) {
                    customBg = it
                    saveThemeChanges()
                    selectedThemeId = "custom"
                    emojiPrefs.themeId = "custom"
                }

                // Standard letter keys swatches
                ColorSwatchRow("Standard Keys Color", currentVal = customKey) {
                    customKey = it
                    saveThemeChanges()
                    selectedThemeId = "custom"
                    emojiPrefs.themeId = "custom"
                }

                // Special keys (Enter/Shift/Backspace) swatches
                ColorSwatchRow("Accent Highlight Color", currentVal = customAccent) {
                    customAccent = it
                    saveThemeChanges()
                    selectedThemeId = "custom"
                    emojiPrefs.themeId = "custom"
                }

                // Letters Text
                ColorSwatchRow("Key Letters Text Color", currentVal = customText) {
                    customText = it
                    saveThemeChanges()
                    selectedThemeId = "custom"
                    emojiPrefs.themeId = "custom"
                }
            }
        }
    }
}

@Composable
fun ThemeCard(theme: KeyboardTheme, isActive: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(130.dp)
            .clickable { onClick() }
            .border(
                width = if (isActive) 3.dp else 1.dp,
                color = if (isActive) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = theme.getComposeBackground())
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = theme.name,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = theme.getComposeKeyText(),
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                if (isActive) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Active",
                        tint = theme.getComposeAccent(),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Tiny representation of lookalike keys
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(18.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(theme.getComposeKeyBg()),
                    contentAlignment = Alignment.Center
                ) {
                    Text("A", fontSize = 8.sp, color = theme.getComposeKeyText(), fontWeight = FontWeight.Bold)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(18.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(theme.getComposeKeyBg()),
                    contentAlignment = Alignment.Center
                ) {
                    Text("S", fontSize = 8.sp, color = theme.getComposeKeyText(), fontWeight = FontWeight.Bold)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(18.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(theme.getComposeAccent()),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🚀", fontSize = 8.sp)
                }
            }
        }
    }
}

@Composable
fun ColorSwatchRow(title: String, currentVal: String, onSelectColor: (String) -> Unit) {
    val swatches = listOf(
        "#1F2124", "#FFFFFF", "#ECEFF1", "#1B3B2B", "#FDF2E9", "#000000", "#1A1B35",
        "#0F1419", "#3E2723", "#006064", "#0D47A1", "#311B92", "#E65100", "#D50000",
        "#E8EAED", "#2C3033", "#F5E0DC", "#8AB4F8", "#77DD77", "#A284F6", "#39FF14"
    )

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(currentVal, fontSize = 11.sp, color = Color.Gray)
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(swatches) { hex ->
                val isSelected = hex.lowercase() == currentVal.lowercase()
                val parsedColor = remember(hex) { Color(android.graphics.Color.parseColor(hex)) }
                
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(parsedColor)
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.4f),
                            shape = CircleShape
                        )
                        .clickable { onSelectColor(hex) },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = if (hex == "#FFFFFF" || hex == "#ECEFF1") Color.Black else Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GesturesTab(emojiPrefs: EmojiSharedPreferences) {
    var selectedDirection by remember { mutableStateOf<String?>(null) }
    var showEmojiDialog by remember { mutableStateOf(false) }

    // Recompilation state key to refresh UI labels
    var updateTrigger by remember { mutableStateOf(0) }

    val poolOfEmojis = listOf(
        "🚀", "❤️", "👍", "😂", "🔥", "✨", "👏", "🎉", 
        "🤔", "👀", "💯", "💀", "💡", "🙌", "🌟", "🦾", 
        "🥳", "🥺", "🥶", "😻", "🌈", "🍕", "🦾", "👾",
        "🫠", "👽", "💩", "🧠", "🦁", "🍿", "🍩", "🎯"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Interactive Gesture Mapping",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "GlideBoard lets you trigger custom emojis instantly by swiping in any of the 8 directions on the Glide Gestures key. Tap a direction pin to custom-assign its shortcut emoji.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Large beautiful 8-directional visual selector compass
        Box(
            modifier = Modifier
                .size(280.dp)
                .align(Alignment.CenterHorizontally)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f))
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Directional pins
            val directions = listOf(
                "up" to Alignment.TopCenter,
                "down" to Alignment.BottomCenter,
                "left" to Alignment.CenterStart,
                "right" to Alignment.CenterEnd,
                "up_left" to Alignment.TopStart,
                "up_right" to Alignment.TopEnd,
                "down_left" to Alignment.BottomStart,
                "down_right" to Alignment.BottomEnd
            )

            directions.forEach { (dir, alignment) ->
                val emojiVal = remember(dir, updateTrigger) { emojiPrefs.getEmoji(dir) }
                
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    contentAlignment = alignment
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .clickable {
                                selectedDirection = dir
                                showEmojiDialog = true
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = emojiVal, fontSize = 24.sp)
                        Text(
                            text = dir.replace("_", " ").uppercase(),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Center compass guide bubble
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Gesture,
                    contentDescription = "Compass Center",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Dialog for mapping direction emoji
        if (showEmojiDialog && selectedDirection != null) {
            Dialog(onDismissRequest = { showEmojiDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Map Swipe ${selectedDirection?.replace("_", " ")?.uppercase()}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Pick an emoji shortcut for this gesture direction:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )

                        // Emoji Grid list inside dialog
                        Box(modifier = Modifier.height(180.dp)) {
                            androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                                columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(5),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                               verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(poolOfEmojis) { emoji ->
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable {
                                                emojiPrefs.saveEmoji(selectedDirection!!, emoji)
                                                updateTrigger++
                                                showEmojiDialog = false
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(emoji, fontSize = 22.sp)
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = { showEmojiDialog = false },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Dismiss")
                        }
                    }
                }
            }
        }
    }
}

// Simple legacy wrapper Card
@Composable
fun Card(
    modifier: Modifier = Modifier,
    border: BorderStroke? = null,
    title: String? = null,
    content: @Composable () -> Unit
) {
    if (border != null) {
        androidx.compose.material3.Card(
            modifier = modifier,
            shape = RoundedCornerShape(12.dp),
            border = border,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            content()
        }
    } else {
        androidx.compose.material3.Card(
            modifier = modifier,
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            content()
        }
    }
}
