package com.example

import androidx.compose.ui.graphics.Color

data class KeyboardTheme(
    val id: String,
    val name: String,
    val isDark: Boolean,
    val backgroundColor: String,
    val keyColor: String,
    val keyTextColor: String,
    val specialKeyColor: String,
    val accentColor: String
) {
    private fun safeParseColor(hex: String, fallback: String): Color {
        return try {
            val cleanHex = hex.trim()
            val formattedHex = if (cleanHex.startsWith("#")) cleanHex else "#$cleanHex"
            Color(android.graphics.Color.parseColor(formattedHex))
        } catch (e: Exception) {
            try {
                Color(android.graphics.Color.parseColor(fallback))
            } catch (ex: Exception) {
                Color.Gray
            }
        }
    }

    fun getComposeBackground(): Color = safeParseColor(backgroundColor, "#1F2124")
    fun getComposeKeyBg(): Color = safeParseColor(keyColor, "#2C3033")
    fun getComposeKeyText(): Color = safeParseColor(keyTextColor, "#E8EAED")
    fun getComposeSpecialKeyBg(): Color = safeParseColor(specialKeyColor, "#35393C")
    fun getComposeAccent(): Color = safeParseColor(accentColor, "#8AB4F8")

    companion object {
        val GBOARD_DARK = KeyboardTheme(
            id = "gboard_dark",
            name = "Gboard Slate Dark",
            isDark = true,
            backgroundColor = "#1F2124",
            keyColor = "#2C3033",
            keyTextColor = "#E8EAED",
            specialKeyColor = "#35393C",
            accentColor = "#8AB4F8"
        )

        val GBOARD_LIGHT = KeyboardTheme(
            id = "gboard_light",
            name = "Gboard Classic Light",
            isDark = false,
            backgroundColor = "#ECEFF1",
            keyColor = "#FFFFFF",
            keyTextColor = "#202124",
            specialKeyColor = "#CFD8DC",
            accentColor = "#1A73E8"
        )

        val DEEP_EMERALD = KeyboardTheme(
            id = "deep_emerald",
            name = "Forest Moss Green",
            isDark = true,
            backgroundColor = "#1B3B2B",
            keyColor = "#2E5B42",
            keyTextColor = "#F1F8F4",
            specialKeyColor = "#396B4E",
            accentColor = "#77DD77"
        )

        val SUNSET_TERRACOTTA = KeyboardTheme(
            id = "sunset_terracotta",
            name = "Sunset Glow",
            isDark = false,
            backgroundColor = "#FDF2E9",
            keyColor = "#FADBD8",
            keyTextColor = "#5C2620",
            specialKeyColor = "#ECCAD6",
            accentColor = "#E67E22"
        )

        val MIDNIGHT_AMOLED = KeyboardTheme(
            id = "midnight_amoled",
            name = "Amoled Night",
            isDark = true,
            backgroundColor = "#000000",
            keyColor = "#1A1A1A",
            keyTextColor = "#FFFFFF",
            specialKeyColor = "#282828",
            accentColor = "#BB86FC"
        )

        val COSMIC_LAVENDER = KeyboardTheme(
            id = "cosmic_lavender",
            name = "Cosmic Purple",
            isDark = true,
            backgroundColor = "#1A1B35",
            keyColor = "#2D2E68",
            keyTextColor = "#F3EBFD",
            specialKeyColor = "#3B3D84",
            accentColor = "#A284F6"
        )

        val CYBERPUNK_TERMINAL = KeyboardTheme(
            id = "cyberpunk_terminal",
            name = "Retro Terminal",
            isDark = true,
            backgroundColor = "#0F1419",
            keyColor = "#17202A",
            keyTextColor = "#39FF14",
            specialKeyColor = "#22313F",
            accentColor = "#39FF14"
        )

        val ALL_THEMES = listOf(
            GBOARD_DARK,
            GBOARD_LIGHT,
            DEEP_EMERALD,
            SUNSET_TERRACOTTA,
            MIDNIGHT_AMOLED,
            COSMIC_LAVENDER,
            CYBERPUNK_TERMINAL
        )

        fun getById(id: String, customTheme: KeyboardTheme? = null): KeyboardTheme {
            if (id == "custom" && customTheme != null) {
                return customTheme
            }
            return ALL_THEMES.find { it.id == id } ?: GBOARD_DARK
        }
    }
}
