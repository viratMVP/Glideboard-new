package com.example

import android.content.Context
import android.content.SharedPreferences

class EmojiSharedPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("glideboard_prefs", Context.MODE_PRIVATE)

    companion object {
        const val KEY_THEME_ID = "selected_theme_id"
        
        // Custom Theme Colors
        const val KEY_CUSTOM_BG = "custom_bg_color"
        const val KEY_CUSTOM_KEY = "custom_key_color"
        const val KEY_CUSTOM_TEXT = "custom_key_text_color"
        const val KEY_CUSTOM_SPECIAL = "custom_special_key_color"
        const val KEY_CUSTOM_ACCENT = "custom_accent_color"

        // Emojis for 8 Directions
        const val KEY_EMOJI_UP = "emoji_up"
        const val KEY_EMOJI_DOWN = "emoji_down"
        const val KEY_EMOJI_LEFT = "emoji_left"
        const val KEY_EMOJI_RIGHT = "emoji_right"
        const val KEY_EMOJI_UP_LEFT = "emoji_up_left"
        const val KEY_EMOJI_UP_RIGHT = "emoji_up_right"
        const val KEY_EMOJI_DOWN_LEFT = "emoji_down_left"
        const val KEY_EMOJI_DOWN_RIGHT = "emoji_down_right"

        // Default Emojis
        const val DEFAULT_UP = "🚀"
        const val DEFAULT_DOWN = "❤️"
        const val DEFAULT_LEFT = "👍"
        const val DEFAULT_RIGHT = "😂"
        const val DEFAULT_UP_LEFT = "🔥"
        const val DEFAULT_UP_RIGHT = "✨"
        const val DEFAULT_DOWN_LEFT = "👏"
        const val DEFAULT_DOWN_RIGHT = "🎉"
    }

    var themeId: String
        get() = prefs.getString(KEY_THEME_ID, "gboard_dark") ?: "gboard_dark"
        set(value) = prefs.edit().putString(KEY_THEME_ID, value).apply()

    fun getCustomTheme(): KeyboardTheme {
        return KeyboardTheme(
            id = "custom",
            name = "My Custom Design",
            isDark = true,
            backgroundColor = prefs.getString(KEY_CUSTOM_BG, "#1E1E2E") ?: "#1E1E2E",
            keyColor = prefs.getString(KEY_CUSTOM_KEY, "#302D41") ?: "#302D41",
            keyTextColor = prefs.getString(KEY_CUSTOM_TEXT, "#D9E0EE") ?: "#D9E0EE",
            specialKeyColor = prefs.getString(KEY_CUSTOM_SPECIAL, "#1E1E2E") ?: "#1E1E2E",
            accentColor = prefs.getString(KEY_CUSTOM_ACCENT, "#F5E0DC") ?: "#F5E0DC"
        )
    }

    fun saveCustomTheme(theme: KeyboardTheme) {
        prefs.edit().apply {
            putString(KEY_CUSTOM_BG, theme.backgroundColor)
            putString(KEY_CUSTOM_KEY, theme.keyColor)
            putString(KEY_CUSTOM_TEXT, theme.keyTextColor)
            putString(KEY_CUSTOM_SPECIAL, theme.specialKeyColor)
            putString(KEY_CUSTOM_ACCENT, theme.accentColor)
        }.apply()
    }

    fun getEmoji(dir: String): String {
        return when (dir.lowercase()) {
            "up" -> prefs.getString(KEY_EMOJI_UP, DEFAULT_UP) ?: DEFAULT_UP
            "down" -> prefs.getString(KEY_EMOJI_DOWN, DEFAULT_DOWN) ?: DEFAULT_DOWN
            "left" -> prefs.getString(KEY_EMOJI_LEFT, DEFAULT_LEFT) ?: DEFAULT_LEFT
            "right" -> prefs.getString(KEY_EMOJI_RIGHT, DEFAULT_RIGHT) ?: DEFAULT_RIGHT
            "up_left" -> prefs.getString(KEY_EMOJI_UP_LEFT, DEFAULT_UP_LEFT) ?: DEFAULT_UP_LEFT
            "up_right" -> prefs.getString(KEY_EMOJI_UP_RIGHT, DEFAULT_UP_RIGHT) ?: DEFAULT_UP_RIGHT
            "down_left" -> prefs.getString(KEY_EMOJI_DOWN_LEFT, DEFAULT_DOWN_LEFT) ?: DEFAULT_DOWN_LEFT
            "down_right" -> prefs.getString(KEY_EMOJI_DOWN_RIGHT, DEFAULT_DOWN_RIGHT) ?: DEFAULT_DOWN_RIGHT
            else -> "😀"
        }
    }

    fun saveEmoji(dir: String, emoji: String) {
        val key = when (dir.lowercase()) {
            "up" -> KEY_EMOJI_UP
            "down" -> KEY_EMOJI_DOWN
            "left" -> KEY_EMOJI_LEFT
            "right" -> KEY_EMOJI_RIGHT
            "up_left" -> KEY_EMOJI_UP_LEFT
            "up_right" -> KEY_EMOJI_UP_RIGHT
            "down_left" -> KEY_EMOJI_DOWN_LEFT
            "down_right" -> KEY_EMOJI_DOWN_RIGHT
            else -> return
        }
        prefs.edit().putString(key, emoji).apply()
    }

    /**
     * Get all gestured emojis as an 8-way directional map.
     */
    fun getAllEmojis(): Map<String, String> {
        return mapOf(
            "up" to getEmoji("up"),
            "down" to getEmoji("down"),
            "left" to getEmoji("left"),
            "right" to getEmoji("right"),
            "up_left" to getEmoji("up_left"),
            "up_right" to getEmoji("up_right"),
            "down_left" to getEmoji("down_left"),
            "down_right" to getEmoji("down_right")
        )
    }
}
